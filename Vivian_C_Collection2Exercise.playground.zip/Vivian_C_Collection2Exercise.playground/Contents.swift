import Cocoa

var greeting = "Hello, playground"

var itemsArray: [String] = ["Pins", "Pens", "Photos", "Erasers"]

print(itemsArray)

//to sort alphabetically
itemsArray.sort()
print(itemsArray.sorted())
